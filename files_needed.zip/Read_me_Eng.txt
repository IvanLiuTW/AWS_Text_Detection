1. Please change the path for medicine_info and medicine_images

2. We set Panadol as the "wrong" image, so it's information is not in our database(medicine_info)

3. There's still a bug of double clicking, and we are still working on it. 

4. If you have any idea or better ways to improve the code, please share with us, thank you!😃